package com.cg.mp.repository;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.cg.mp.bean.Customer;
import com.cg.mp.bean.Mobile;

public class MobileRepoImplements implements IMobileRepository {
	Map<Integer,Mobile>hm=new HashMap<>();
	Map<Integer,Customer>cusMap=new HashMap<>();
	Map<Integer,Mobile> findmob=new HashMap<>();
	Mobile mob=new Mobile();
	MobileRepoImplements repoimp;
  /*  public MobileRepoImplements(Map<Integer, Mobile> hm) 
	 {
    	super();
	this.hm=hm;
	}*/
	 
    


	public Map<Integer,Mobile> mobiles()
	 {
		 hm.put(1001 , new Mobile(1001,20,30000,"Nokia"));
		 hm.put(1002 , new Mobile(1002,30,40000,"Samsung"));
		 hm.put(1003 , new Mobile(1003,10,50000,"OnePlus"));
		 hm.put(1004 , new Mobile(1041,50,20000,"Sony"));
		 System.out.println(hm);
       return  hm;
	 }
	@Override
	public Customer add(Customer cusMap) {
       
		cusMap.put(cusMap.getMobileId(),cusMap);
       return cusMap;
	}

	@Override
	public Map<Integer,Mobile> showMobDetails() {
		{
			return mobiles();
		
			
		}
	}
	
	Map<Integer,Mobile> newMap = new HashMap<>();
	@Override
	public 	 Map<Integer,Mobile> findByPrice(float Price1) {
		 hm.put(1001 , new Mobile(1001,20,30000.45f,"Nokia"));
		 hm.put(1002 , new Mobile(1002,30,40000.50f,"Samsung"));
		 hm.put(1003 , new Mobile(1003,10,50000.45f,"OnePlus"));
		 hm.put(1004 , new Mobile(1041,50,20000.45f,"Sony"));
		
	return hm;
		
	}
	@Override
	public void updateQuanity(int mobId, int mobquantity) {
		
		//hm.get(mobId).setMobQuantity((hm.get(mobId).getMobQuantity())-mobquantity);
		replace(hm.get(mobId),hm.get(mobId).getMobQuantity(),(hm.get(mobId).getMobQuantity())-mobquantity);
		//hm.put(hm.get(mobId),hm.get(mobId).getMobQuantity(),(hm.get(mobId).getMobQuantity())-mobquantity);
	}


	@Override
	public boolean IsfindId(int mobileId) {
		// TODO Auto-generated method stub
		if(!hm.containsKey(mobileId))
			return false;
	return true;
		
	}
}
