package com.pg.mp.exception;

public class InvalidPhoneException extends RuntimeException {
public InvalidPhoneException(String msg)
{
	super(msg);
}
	
}
