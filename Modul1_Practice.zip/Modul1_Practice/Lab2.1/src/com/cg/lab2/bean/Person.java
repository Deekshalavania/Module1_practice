package com.cg.lab2.bean;

public class Person {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("First Name:" +"Divya");
		System.out.println("Last Name:" +"Bharthi");
		System.out.println("Gender:"+"F");
		System.out.println("Age:"+ 20);
		System.out.println("Weight:"+ 85.55);

	}

}
