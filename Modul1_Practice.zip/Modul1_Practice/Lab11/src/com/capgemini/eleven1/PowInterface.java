package com.capgemini.eleven1;

public interface PowInterface {
public double power(double x,double y);
	
}
