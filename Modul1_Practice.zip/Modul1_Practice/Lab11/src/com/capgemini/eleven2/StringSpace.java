package com.capgemini.eleven2;

public abstract class StringSpace implements IStringSpace {
    public static void main(String[] args) {
	 
    	IStringSpace e = (tring)->{ System.out.println(tring.replace(""," "));};
    	e.space("hai");
}
    
}