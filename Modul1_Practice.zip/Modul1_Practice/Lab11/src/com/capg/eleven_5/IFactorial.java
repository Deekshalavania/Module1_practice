package com.capg.eleven_5;

public interface IFactorial {
  public void fact();
}
