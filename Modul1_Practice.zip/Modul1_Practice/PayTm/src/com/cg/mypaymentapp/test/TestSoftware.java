package com.cg.mypaymentapp.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestSoftware {

	@Test(expected= com.cg.bean.exception.InavlidQuantityOrCodeException.class)
	public void test() {

	}
	@Test(expected=com.cg.mypaymentapp.exception.InvalidInputException.class)
	{
		public void testsoftware()
		{
			
		}
	}
}
